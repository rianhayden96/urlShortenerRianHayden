package com.example.demo;

public class UrlObj {

    public String fullUrl;
    public long idNum;

    /*
    Getter and Setter for the full Url and Ids
     */

    public String getFullUrl() {
        return fullUrl;
    }

    public void setFullUrl(String fullUrl) {
        this.fullUrl = fullUrl;
    }

    public long getIdNum() {
        return idNum;
    }

    public void setIdNum(long idNum) {
        this.idNum = idNum;
    }
}
